import { type LintCheck } from './lintTypes.js';
export declare const isWriteRequest: (text: string) => boolean;
/** Explicit tool syntax and exact registered names; prose and API members are excluded. */
export declare function toolTokens(text: string, registered: readonly string[]): string[];
export declare function toolsCheck(text: string, names: readonly string[]): LintCheck;
/** URLs, CIDR and ordinary alternatives are never filesystem paths. */
export declare function pathTokens(text: string): string[];
export declare function mentionTokens(text: string): string[];
export interface MentionName {
    name: string;
    modelInvocable?: boolean;
}
export declare function editDistance(left: string, right: string): number;
export declare function mentionsCheck(text: string, names: readonly MentionName[]): LintCheck;
export declare function permissionsCheck(text: string, policy: 'ask' | 'never' | undefined): LintCheck;
export declare function deliverablesCheck(text: string): LintCheck;
