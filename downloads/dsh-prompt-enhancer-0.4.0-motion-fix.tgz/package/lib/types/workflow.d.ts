import type { EnhanceOutcome } from './resultStore.js';
export type RewriteMode = 'quick' | 'preview' | 'conditioned';
export interface Activity {
    busy: boolean;
    mode?: RewriteMode;
    notice?: string;
    cancelled?: boolean;
}
declare const commands: Map<string, {
    run(mode: RewriteMode, original?: string): Promise<void>;
    cancel(previewOnly?: boolean): void;
}>;
/** One request owner per composer, independent from the optional sidebar. */
export declare const workflow: {
    state: (id: string) => Activity;
    set(id: string, value: Activity): void;
    subscribe(listener: () => void): () => void;
    register(id: string, command: NonNullable<ReturnType<typeof commands.get>>): () => void;
    run(id: string, mode: RewriteMode, original?: string): Promise<void>;
    cancel(id: string, previewOnly?: boolean): void;
    panelView: (id: string) => "result" | "checks";
    openView(id: string, view: "result" | "checks"): void;
    clear(): void;
};
export declare function matchesOutcome(outcome: EnhanceOutcome, draft: string, rev: number): boolean;
export {};
