import { z } from 'zod';
import type { InvocationDescriptor, RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { LintReport } from './lintTypes.js';
export declare const PACKAGE = "dsh-prompt-enhancer";
export declare const ENDPOINT: "promptEnhancer/enhance";
export declare const POLICY_ENDPOINT: "promptEnhancer/policy";
export declare const LINT_ENDPOINT: "promptEnhancer/lint";
export declare const lintReportSchema: z.ZodObject<{
    checks: z.ZodArray<z.ZodObject<{
        category: z.ZodEnum<{
            tools: "tools";
            paths: "paths";
            mentions: "mentions";
            permissions: "permissions";
            deliverables: "deliverables";
        }>;
        state: z.ZodEnum<{
            ok: "ok";
            warn: "warn";
            unknown: "unknown";
        }>;
        findings: z.ZodArray<z.ZodObject<{
            state: z.ZodEnum<{
                ok: "ok";
                warn: "warn";
                unknown: "unknown";
            }>;
            severity: z.ZodEnum<{
                none: "none";
                info: "info";
                warning: "warning";
            }>;
            code: z.ZodString;
            reason: z.ZodString;
            token: z.ZodOptional<z.ZodString>;
            suggestion: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    elapsedMs: z.ZodNumber;
}, z.core.$strict>;
export declare const lintRequestSchema: z.ZodObject<{
    text: z.ZodString;
}, z.core.$strict>;
export type LintRequest = z.infer<typeof lintRequestSchema>;
export declare const requestSchema: z.ZodObject<{
    text: z.ZodString;
    lint: z.ZodOptional<z.ZodObject<{
        checks: z.ZodArray<z.ZodObject<{
            category: z.ZodEnum<{
                tools: "tools";
                paths: "paths";
                mentions: "mentions";
                permissions: "permissions";
                deliverables: "deliverables";
            }>;
            state: z.ZodEnum<{
                ok: "ok";
                warn: "warn";
                unknown: "unknown";
            }>;
            findings: z.ZodArray<z.ZodObject<{
                state: z.ZodEnum<{
                    ok: "ok";
                    warn: "warn";
                    unknown: "unknown";
                }>;
                severity: z.ZodEnum<{
                    none: "none";
                    info: "info";
                    warning: "warning";
                }>;
                code: z.ZodString;
                reason: z.ZodString;
                token: z.ZodOptional<z.ZodString>;
                suggestion: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        elapsedMs: z.ZodNumber;
    }, z.core.$strict>>;
    selection: z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
        reasoningEffort: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const responseSchema: z.ZodObject<{
    text: z.ZodString;
}, z.core.$strict>;
export type EnhanceRequest = z.infer<typeof requestSchema>;
export type EnhanceResponse = z.infer<typeof responseSchema>;
export declare const policySchema: z.ZodObject<{
    timeoutMs: z.ZodNumber;
}, z.core.$strict>;
export type EnhancePolicy = z.infer<typeof policySchema>;
export declare const descriptor: InvocationDescriptor;
export declare const policyDescriptor: InvocationDescriptor;
export declare const lintDescriptor: InvocationDescriptor;
export declare const contribution: TypertRemoteContribution;
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteMap {
        'promptEnhancer/enhance': (sessionId: SessionId, request: EnhanceRequest, signal?: AbortSignal) => Promise<RemoteResult<EnhanceResponse>>;
        'promptEnhancer/policy': (sessionId: SessionId, signal?: AbortSignal) => Promise<RemoteResult<EnhancePolicy>>;
        'promptEnhancer/lint': (sessionId: SessionId, request: LintRequest, signal?: AbortSignal) => Promise<RemoteResult<LintReport>>;
    }
    interface TypertRemoteNamespaceMap {
        promptEnhancer: {
            policy(sessionId: SessionId, signal?: AbortSignal): Promise<RemoteResult<EnhancePolicy>>;
            enhance(sessionId: SessionId, request: EnhanceRequest, signal?: AbortSignal): Promise<RemoteResult<EnhanceResponse>>;
            lint(sessionId: SessionId, request: LintRequest, signal?: AbortSignal): Promise<RemoteResult<LintReport>>;
        };
    }
    interface RemoteErrorDetailsMap {
        'prompt-enhancer/rejected': {
            readonly reason: string;
        };
    }
}
export default contribution;
