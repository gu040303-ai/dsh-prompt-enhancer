import { posix } from 'node:path';
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import { type LintCategory, type LintCheck, type LintReport } from './lintTypes.js';
/** A deadline bounds providers which ignore cancellation; cancellation still reaches cooperative providers. */
export declare function boundedCheck(category: LintCategory, task: (signal: AbortSignal) => Promise<LintCheck>, signal: AbortSignal, timeoutMs?: number): Promise<LintCheck>;
/** Lexical containment is checked BEFORE resolve, which may itself perform realpath I/O. */
export declare function lexicalPath(cwd: string, token: string): {
    path: string;
    inside: boolean;
    parts: string[];
    flavor: typeof posix;
};
/** Each category gets at most 500ms, and all categories share a 1500ms overall deadline. */
export declare function lintDraft(ctx: Context, session: Session, text: string, signal: AbortSignal, budget?: {
    itemMs: number;
    totalMs: number;
}): Promise<LintReport>;
