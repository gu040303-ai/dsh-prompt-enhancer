/** Strip presentation markup, never operators or the user's literal code. */
export declare function plainPrompt(value: string, original?: string): string;
