/** Locale keys of the failure copy the composer may report. */
export type FailureKey = 'changed' | 'timeout' | 'tooLong' | 'busy' | 'incomplete' | 'emptyOutput' | 'auth' | 'rateLimit' | 'forbidden' | 'failed';
/**
 * @param error - whatever the remote call threw.
 * @param aborted - whether the caller cancelled the request.
 * @returns the locale key describing the failure, with the same precedence the
 * remote's reason codes and gateway codes are documented to have.
 */
export declare function failureKey(error: unknown, aborted: boolean): FailureKey;
