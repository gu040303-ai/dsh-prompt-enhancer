import type { FidelityReport } from './fidelity.js';
/** One applied enhancement, kept until the user dismisses it or the draft moves on. */
export interface EnhanceOutcome {
    sessionId: string;
    /** The draft before the rewrite, used to undo and to retry. */
    original: string;
    /** The text actually written back into the editor. */
    enhanced: string;
    /** Preview does not modify the editor until the user applies all selected sentences. */
    applied?: boolean;
    base?: string;
    draftRev?: number;
    elapsedMs: number;
    report: FidelityReport;
    sourceMode?: 'quick' | 'preview' | 'conditioned';
    reviewReason?: 'facts';
    /** Publish counter: a fresh value remounts the result text so its reveal replays. */
    seq?: number;
}
/**
 * Session-keyed result channel shared by the composer button and the strip.
 * A module singleton is enough: both entries are loaded from this one bundle,
 * and every reader re-subscribes through `useSyncExternalStore`.
 */
export declare const resultStore: {
    publish(outcome: EnhanceOutcome): void;
    dismiss(sessionId: string): void;
    /** @returns the stored outcome, stable by identity until it is replaced. */
    snapshot(sessionId: string): EnhanceOutcome | undefined;
    subscribe(listener: () => void): () => void;
    /** Drop every session's outcome; called when the plugin is disposed. */
    clear(): void;
};
