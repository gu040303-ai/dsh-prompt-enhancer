import type { EnhanceButtonProps, EnhanceInjected } from './EnhanceButton.js';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export interface PanelInjected extends EnhanceInjected {
}
export type EnhancePanelProps = EnhanceButtonProps & Pick<PropsRuntime<'sidebar.right.pane.tab'>, 'useTabInfo'>;
export declare function EnhancePanel(props: EnhancePanelProps): import("react").JSX.Element;
