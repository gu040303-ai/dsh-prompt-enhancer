import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type Session } from '@deepseek-ai/dsh-session';
import type { AuditRequest, Limits } from './enhance.js';
import { type EnhanceRequest, type EnhanceResponse, type EnhancePolicy, type LintRequest } from './remote.js';
import type { LintReport } from './lintTypes.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        promptEnhancerController: PromptEnhancerController;
    }
}
declare module '@deepseek-ai/dsh-session' {
    interface PluginRecordMap {
        'plugin:prompt-enhancer/request': AuditRequest;
    }
}
/** Cordis owns the service, descriptor, in-flight cancellation and hot disposal. */
export default class PromptEnhancerController extends TypertRemoteService {
    static inject: string[];
    static Config: z<Limits>;
    private readonly lifetime;
    private readonly active;
    private readonly limits;
    constructor(ctx: Context, config: Limits);
    /**
     * @param session - lookup carrying the caller's Session-resource authorization.
     * @param signal - cancellation from the Remote carrier.
     * @returns public execution limits, without provider configuration or credentials.
     */
    policy(session: Session, signal: AbortSignal): EnhancePolicy;
    /** Read-only local preflight, bound to the same authenticated Session lookup. */
    lint(session: Session, request: LintRequest, signal: AbortSignal): Promise<LintReport>;
    /**
     * @param session - Gateway-resolved Session; lookup also supplies resource authorization.
     * @param request - unsent draft and the model currently selected in the host UI.
     * @param signal - cancellation supplied by Harness's authenticated RPC carrier.
     * @returns a complete replacement draft; this method never submits it.
     */
    enhance(session: Session, request: EnhanceRequest, signal: AbortSignal): Promise<EnhanceResponse>;
}
