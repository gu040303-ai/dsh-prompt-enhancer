/**
 * Offline fidelity check: which hard facts of the draft survived the rewrite.
 *
 * Everything here is deterministic and costs no model call. A missing fact is
 * reported, never used to block the write-back: the user decides whether to
 * look at the difference or to append the lost detail again.
 */
export type FactKind = 'code' | 'path' | 'url' | 'mention' | 'number';
export interface Fact {
    kind: FactKind;
    value: string;
}
export interface FidelityReport {
    /** Distinct hard facts found in the original draft, in first-seen order. */
    facts: Fact[];
    kept: Fact[];
    lost: Fact[];
}
/**
 * @param text - the draft as the user typed it.
 * @returns distinct hard facts, code spans first so their contents are not
 * re-reported as paths, URLs or numbers.
 */
export declare function extractFacts(text: string): Fact[];
/**
 * @param original - the draft that was sent to the model.
 * @param enhanced - the text the model returned.
 * @returns the facts, split into kept and lost by exact containment.
 */
export declare function compareFacts(original: string, enhanced: string): FidelityReport;
/**
 * @param text - the enhanced draft.
 * @param facts - facts the enhancement dropped.
 * @param header - localized label introducing the block, supplied by the UI so
 * the appended text stays in the language the user is writing in.
 * @returns the draft with an explicit trailing block, so the agent still
 * receives every detail the user originally wrote. Returns `text` unchanged
 * when nothing was lost.
 */
export declare function appendFacts(text: string, facts: Fact[], header: string): string;
