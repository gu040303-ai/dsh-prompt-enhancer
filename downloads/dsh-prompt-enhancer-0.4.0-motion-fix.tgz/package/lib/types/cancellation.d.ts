/** Bound an operation even when its producer fails to observe cancellation. */
export declare function untilAbort<T>(operation: PromiseLike<T>, signal: AbortSignal): Promise<T>;
