import type { Context } from '@deepseek-ai/cordis';
import { EnhanceButton } from './EnhanceButton.js';
import { EnhanceResult, EnhanceFeedback } from './EnhanceResult.js';
import { resultStore } from './resultStore.js';
import { EnhanceLauncher } from './EnhanceLauncher.js';
import { EnhancePanel } from './EnhancePanel.js';
import { workflow } from './workflow.js';
export { EnhanceButton, EnhanceResult, EnhanceFeedback, EnhancePanel, EnhanceLauncher, resultStore, workflow };
export declare const PANEL_ID = "dsh-prompt-enhancer/panel";
export declare const PANEL_KIND = "prompt-enhancer";
export declare const inject: string[];
/** Mount the private Remote namespace and withdraw UI before its RPC contribution. */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
