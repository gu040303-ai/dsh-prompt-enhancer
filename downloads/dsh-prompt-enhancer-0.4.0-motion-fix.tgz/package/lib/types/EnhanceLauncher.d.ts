import { type EnhanceButtonProps } from './EnhanceButton.js';
export type EnhanceLauncherProps = EnhanceButtonProps;
export declare function EnhanceLauncher(props: EnhanceLauncherProps): import("react").JSX.Element;
