import { type ReactNode } from 'react';
import { type EnhanceButtonProps } from './EnhanceButton.js';
export type EnhanceResultProps = EnhanceButtonProps & {
    details?: ReactNode;
};
/** A compact, wrapping status row with actions for the current request only. */
export declare function EnhanceFeedback(props: EnhanceButtonProps): import("react").JSX.Element | null;
export declare function EnhanceResult(props: EnhanceResultProps): import("react").JSX.Element;
