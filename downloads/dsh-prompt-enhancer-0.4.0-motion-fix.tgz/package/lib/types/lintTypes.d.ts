/** Public, content-free preflight vocabulary shared by Host and Client. */
export type LintCategory = 'tools' | 'paths' | 'mentions' | 'permissions' | 'deliverables';
export type LintState = 'ok' | 'warn' | 'unknown';
export interface LintFinding {
    state: LintState;
    severity: 'none' | 'info' | 'warning';
    code: string;
    reason: string;
    token?: string;
    suggestion?: string;
}
export interface LintCheck {
    category: LintCategory;
    state: LintState;
    findings: LintFinding[];
}
export interface LintReport {
    checks: LintCheck[];
    elapsedMs: number;
}
export declare const LINT_CATEGORIES: readonly LintCategory[];
export declare function finding(state: LintState, code: string, reason: string, token?: string): LintFinding;
export declare function check(category: LintCategory, findings: LintFinding[]): LintCheck;
export declare function unknownCheck(category: LintCategory, code?: string): LintCheck;
/** Only verified warnings can influence a rewrite. Informational hints never do. */
export declare function rewriteFindings(report: LintReport): LintFinding[];
