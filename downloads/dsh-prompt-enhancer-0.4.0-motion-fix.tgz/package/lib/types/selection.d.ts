/** Exact-text sentence choices: assembling is pure; applying stays one editor transaction. */
export interface SentenceChoice {
    id: number;
    same: boolean;
    before: string;
    after: string;
}
export interface SentenceReview {
    choices: SentenceChoice[];
    truncated: boolean;
}
export declare function sentenceReview(before: string, after: string): SentenceReview;
export declare function assembleReview(review: SentenceReview, selected: ReadonlySet<number>): string;
