import type { InjectFace, PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { EnhanceResponse } from './remote.js';
import type { LintReport } from './lintTypes.js';
export interface EnhanceInjected {
    available: boolean;
    enhance(text: string, signal: AbortSignal, lint?: LintReport): Promise<EnhanceResponse>;
    lint(text: string, signal: AbortSignal): Promise<LintReport>;
    openPanel(view?: 'result' | 'checks'): void;
}
export type EnhanceButtonProps = Pick<PropsRuntime<'conversation.input.right'>, 'sessionId' | 'inputActions' | 'useInput' | 'useSession' | 'useAccess'> & PropsLocale<'promptEnhancer'> & InjectFace<EnhanceInjected>;
export declare function useActivity(sessionId: string): import("./workflow.js").Activity;
/** Lives with the composer. Opening or closing the optional sidebar cannot own a quick request. */
export declare function useEnhancementController(props: EnhanceButtonProps): {
    blocked: "unavailable" | "forbidden" | "empty" | "command" | "references" | undefined;
    activity: import("./workflow.js").Activity;
};
/** The advanced panel starts a preview; the launcher is the only request owner. */
export declare function EnhanceButton({ sessionId, t, ...props }: EnhanceButtonProps): import("react").JSX.Element;
